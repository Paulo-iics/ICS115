package com.example.labexerno2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText uni1, uni2, uni3, uni4, uni5, uni6, uni7, uni8;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uni1 = findViewById(R.id.s1);
        uni2 = findViewById(R.id.s2);
        uni3 = findViewById(R.id.s3);
        uni4 = findViewById(R.id.s4);
        uni5 = findViewById(R.id.s5);
        uni6 = findViewById(R.id.s6);
        uni7 = findViewById(R.id.s7);
        uni8 = findViewById(R.id.s8);
    }

    public void saveData(View v){
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        String school1 = uni1.getText().toString();
        String school2 = uni2.getText().toString();
        String school3 = uni3.getText().toString();
        String school4 = uni4.getText().toString();
        String school5 = uni5.getText().toString();
        String school6 = uni6.getText().toString();
        String school7 = uni7.getText().toString();
        String school8 = uni8.getText().toString();
        editor.putString("school1", school1);
        editor.putString("school2", school2);
        editor.putString("school3", school3);
        editor.putString("school4", school4);
        editor.putString("school5", school5);
        editor.putString("school6", school6);
        editor.putString("school7", school7);
        editor.putString("school8", school8);
        editor.commit();
        Toast.makeText(this, "Schools are now saved", Toast.LENGTH_LONG).show();



    }

    public void nextPage(View view){
        Intent intent = new Intent(MainActivity.this, Main2Activity.class);
        startActivity(intent);
    }

}
