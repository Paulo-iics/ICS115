package com.example.labexerno2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    EditText uni1, uni2, uni3, uni4, uni5, uni6, uni7, uni8;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void display(View v){
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        String uni1SP = sp.getString("school1", null);
        String uni2SP = sp.getString("school2", null);
        String uni3SP = sp.getString("school3", null);
        String uni4SP = sp.getString("school4", null);
        String uni5SP = sp.getString("school5", null);
        String uni6SP = sp.getString("school6", null);
        String uni7SP = sp.getString("school7", null);
        String uni8SP = sp.getString("school8", null);
        String school1 = uni1.getText().toString();
        String school2 = uni2.getText().toString();
        String school3 = uni3.getText().toString();
        String school4 = uni4.getText().toString();
        String school5 = uni5.getText().toString();
        String school6 = uni6.getText().toString();
        String school7 = uni7.getText().toString();
        String school8 = uni8.getText().toString();
        if(uni1SP.equals(school1) && uni2SP.equals(school2) && uni3SP.equals(school3) && uni4SP.equals(school4) && uni5SP.equals(school5) && uni6SP.equals(school6) && uni7SP.equals(school7) && uni8SP.equals(school8)){
            Toast.makeText(this, "School is competing in the UAAP", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "School is competing in the UAAP",Toast.LENGTH_LONG).show();

        }




    }
}
